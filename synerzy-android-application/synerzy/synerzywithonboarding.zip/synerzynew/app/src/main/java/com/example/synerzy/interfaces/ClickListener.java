package com.example.synerzy.interfaces;

public interface ClickListener {
    void onClickItem(String filePath);
}
